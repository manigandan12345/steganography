#ifndef COMMON_H
#define COMMON_H

#define MAGIC_STRING "#*"

#define MAX_FILE_SUFFIX 4

#endif
